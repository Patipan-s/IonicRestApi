<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

//get all president 
$app->get('/main',function(Request $request, Response $response){
    $sql = "SELECT * FROM productlists WHERE type = 1";
    try{
        $db = new db();
        $db = $db->connect();
        $stmt = $db->query($sql);
        $president = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        // header('Content-type:application/json;charset=utf-8');
        echo json_encode($president,JSON_PRETTY_PRINT);
        // return $response->withJson($product, 200, JSON_NUMERIC_CHECK);
        // JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE
    }catch(PDOException $e){
        echo $e->getMessage();
    }
});

$app->get('/snack',function(Request $request, Response $response){
    $sql = "SELECT * FROM productlists WHERE type = 2";
    try{
        $db = new db();
        $db = $db->connect();
        $stmt = $db->query($sql);
        $president = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($president,JSON_PRETTY_PRINT);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
});

$app->get('/drink',function(Request $request, Response $response){
    $sql = "SELECT * FROM productlists WHERE type = 3";
    try{
        $db = new db();
        $db = $db->connect();
        $stmt = $db->query($sql);
        $president = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($president,JSON_PRETTY_PRINT);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
});
